function [L_processed, spur_indices] = pn_post_processing(f, L_raw, params)
% PN_POST_PROCESSING 相位噪声后处理（强力修复版）
% 策略：硬阈值裁剪 + 线性插值修复杂散 + 强平滑

    % --- 1. 参数解析 ---
    p = inputParser;
    addParameter(p, 'SpurThreshold', -80);
    addParameter(p, 'SpurRatio', 3);
    addParameter(p, 'SmoothWindow', 11); % 【修改】默认窗口加大，平滑效果更强
    addParameter(p, 'JitterRange', []);
    parse(p, params);

    L_out = L_raw;
    spur_indices = [];

    % --- 2. 【强力修复下刺】硬底噪限制 ---
    % 原理：相位噪声物理上很难低于 -200 dBc/Hz（通常是计算溢出或相干性失效）。
    % 任何低于 -180 dBc/Hz 的点直接视为无效数据 (NaN)，绘图时会自动消失。
    floor_limit = -180; 
    L_out(L_out < floor_limit) = NaN;

    % --- 3. 【强力修复上刺】杂散抑制（线性插值版） ---
    % 不再只是简单的中值替换，而是用前后点的连线来“修补”尖峰
    if params.SpurRatio > 0
        L_out = suppress_spurs_interp(L_out, params.SpurThreshold, params.SpurRatio);
    end

    % --- 4. 平滑处理 ---
    % 注意：因为前面已经清洗了异常值，这里的平滑会非常干净
    if params.SmoothWindow > 1
        L_out = smooth_data(L_out, params.SmoothWindow);
    end
    
    % --- 5. 【备用】最终清洗 ---
    % 如果还有极其离谱的残留，再次强制清洗（防御性编程）
    try
        % 再次确保没有低于底噪的点
        L_out(L_out < floor_limit) = NaN;
    catch
        % 忽略错误
    end

    L_processed = L_out;
end

% =================================================================
% 子函数区域
% =================================================================

function L_clean = suppress_spurs_interp(L, thresh_dB, ratio)
    % 使用线性插值修复杂散，比中值替换更平滑
    L_clean = L;
    len = length(L);
    if len < 5, return; end
    
    % 找出需要修复的点的索引
    spur_idx = [];
    
    for i = 3 : len-2
        % 只有当数据有效时才判断
        if ~isnan(L(i))
            local_window = L([i-2, i-1, i+1, i+2]);
            % 忽略局部窗口里的 NaN
            local_window = local_window(~isnan(local_window));
            
            if ~isempty(local_window)
                local_median = median(local_window);
                % 判断条件：比周围高出 ratio dB 且 超过阈值
                if (L(i) > local_median + ratio) && (L(i) > thresh_dB)
                    spur_idx = [spur_idx, i];
                end
            end
        end
    end
    
    % 批量修复：将尖峰置为 NaN，然后利用前后点进行插值
    if ~isempty(spur_idx)
        L_temp = L_clean;
        L_temp(spur_idx) = NaN;
        % fillmissing 使用线性插值填补空缺
        L_clean = fillmissing(L_temp, 'linear'); 
    end
end

function L_smooth = smooth_data(L, win_size)
    % 确保窗口是奇数
    if mod(win_size, 2) == 0, win_size = win_size + 1; end
    
    % 使用 movmedian (移动中值) 代替 conv (卷积平均)
    % movmedian 对残留的微小毛刺有更好的抵抗力，且能更好地保持曲线边缘
    L_smooth = movmedian(L, win_size, 'omitnan');
end

function jitter_rms = calculate_rms_jitter(f, L, f_carrier, range)
    if nargin < 4 || isempty(range)
        f_start = f(2); 
        f_stop = f(end);
    else
        f_start = range(1);
        f_stop = range(2);
    end

    idx = (f >= f_start) & (f <= f_stop);
    f_int = f(idx);
    L_int = L(idx);

    if length(f_int) < 2
        jitter_rms = NaN;
        return;
    end

    valid_idx = ~isnan(L_int);
    if ~any(valid_idx)
        jitter_rms = NaN;
        return;
    end
    
    S_phi = 2 * 10.^(L_int(valid_idx) / 10);
    phase_var = trapz(f_int(valid_idx), S_phi);

    if phase_var < 0
        jitter_rms = NaN;
    else
        jitter_rms = sqrt(phase_var) / (2 * pi * f_carrier);
    end
end
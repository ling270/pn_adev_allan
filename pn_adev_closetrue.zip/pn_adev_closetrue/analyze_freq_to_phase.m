function phase_data = analyze_freq_to_phase(input_file, output_file, Fs, dtrend_mode)
    % analyze_freq_to_phase - 读取频率文件，转换为相位，保存并绘图
    %
    % 输入参数:
    %   input_file  : 输入频率波动文件路径 (二进制 double)
    %   output_file : 输出相位波动文件路径 (二进制 double)
    %   Fs          : 采样率 (Hz)
    %   dtrend_mode : 去趋势模式 (0 = 'linear', 1 = 'constant')
    %
    % 输出:
    %   phase_data  : 去趋势后的相位数据向量

    %% 1. 读取频率数据
    if ~exist(input_file, 'file')
        error('输入文件不存在: %s', input_file);
    end
    
    fid = fopen(input_file, 'rb');
    freq_data = fread(fid, 'double');
    fclose(fid);
    
    N = length(freq_data);
    fprintf('正在处理: %s (数据点: %d)\n', input_file, N);
    
    %% 2. 频率转相位 (积分)
    % 物理公式: φ(t) = ∫ 2πf(t) dt
    dt = 1 / Fs;
    phase_raw = cumsum(2 * pi * freq_data * dt);
    
    %% 3. 去趋势处理
    if dtrend_mode == 0
        trend_type = 'linear';
    else
        trend_type = 'constant';
    end
    phase_data = detrend(phase_raw, trend_type);
    
    %% 4. 保存去趋势后的相位文件
    fid = fopen(output_file, 'w');
    fwrite(fid, phase_data, 'double');
    fclose(fid);
    
    %% 5. 绘图 (前 10000 点)
    plot_points = min(10000, N);
    t_axis = (0:plot_points-1) / Fs; % 时间轴
    
    figure('Color', 'w', 'Position', [100, 100, 1000, 800]);
    
    % 子图 1: 频率波动
    subplot(3, 1, 1);
    plot(t_axis, freq_data(1:plot_points), 'b');
    grid on;
    title(['Frequency Fluctuation (First ' num2str(plot_points) ' points)']);
    ylabel('Frequency (Hz)');
    
    % 子图 2: 原始相位
    subplot(3, 1, 2);
    plot(t_axis, phase_raw(1:plot_points), 'Color', [0.85 0.3 0.2]);
    grid on;
    title('Raw Phase (Integrated, with Drift)');
    ylabel('Phase (rad)');
    
    % 子图 3: 去趋势后的相位
    subplot(3, 1, 3);
    plot(t_axis, phase_data(1:plot_points), 'k', 'LineWidth', 1);
    grid on;
    title(['Detrended Phase (' trend_type ' trend removed)']);
    xlabel('Time (s)');
    ylabel('Phase (rad)');
    
    % 统一字体设置
    sgtitle(['Analysis: ' input_file], 'FontSize', 14);
    set(findall(gcf, '-property', 'FontName'), 'FontName', 'Times New Roman', 'FontSize', 12);
    
    fprintf('✅ 处理完成，文件已保存至: %s\n', output_file);
end
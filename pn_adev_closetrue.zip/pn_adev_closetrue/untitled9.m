clc; clear; close all;

%% 1. 读取数据
filename = 'datasource4/df12_10Hz.dat';
fid = fopen(filename, 'rb');
if fid < 0
    error('无法打开文件 %s，请检查文件路径是否正确。', filename);
end

% 读取所有数据，格式为 'double'
raw_data = fread(fid, 'double');
fclose(fid);

% 确保是列向量
raw_data = raw_data(:);
fprintf('✅ 成功读取数据，原始长度: %d\n', length(raw_data));

%% 2. 参数设置
% 原始采样率配置
FS = 133000000;
CIC_R = 64;
Fs_base = FS / CIC_R; % 2,078,125 Hz

Fs_current = Fs_base; 
DecFactor_Main = 10;   % 前4级每级的降采样倍数
TotalStages_Main = 4;  % 前4级的级数

% 每一级要剔除的无效点数
PointsToTrim = 300;

% 创建输出目录
outDir = 'datasource4/10Hz_decimated_results';
if ~exist(outDir, 'dir')
    mkdir(outDir);
end

%% 3. 第一阶段：级联降采样 (4级 x 10倍 -> 约 207.8 Hz)
current_data = raw_data;

fprintf('>>> 开始第一阶段：4级 x10 降采样...\n');

for i = 1:TotalStages_Main
    fprintf('   正在处理第 %d 级 (Fs: %.1f -> %.1f Hz)...\n', i, Fs_current, Fs_current/DecFactor_Main);
    
    % 执行降采样
    y_filtered = MULTISPEED(current_data);
    
    % 剔除无效点
    if length(y_filtered) > PointsToTrim
        current_data = y_filtered(PointsToTrim + 1 : end);
    else
        error('第 %d 级处理后数据过短。', i);
    end
    
    % 更新采样率
    Fs_current = Fs_current / DecFactor_Main;
end

fprintf('   -> 第一阶段完成。当前采样率: %.2f Hz\n', Fs_current);

%% 4. 第二阶段：最后一级降采样 (dec_4 -> 约 52 Hz)
% 注意：这里不再使用 MULTISPEED，而是使用 dec_4
fprintf('>>> 开始第二阶段：最后一级 dec_4 降采样 (x4)...\n');

% 调用 dec_4 函数
y_final_raw = dec_4(current_data);

% 更新采样率 (207.8 / 4 ≈ 51.95 Hz)
Fs_final = Fs_current / 4;

% 剔除 dec_4 带来的延迟
% dec_4 滤波器阶数约500，延迟约250个输入点。
% 输出端延迟 ≈ 250 / 4 ≈ 63 个点。为了安全取 70。
DelayPoints_Dec4 = 70;

if length(y_final_raw) > DelayPoints_Dec4
    final_data = y_final_raw(DelayPoints_Dec4 + 1 : end);
else
    error('数据过短，无法剔除 dec_4 的延迟。');
end

fprintf('   -> 第二阶段完成。最终采样率: %.2f Hz\n', Fs_final);

%% 5. 保存最终文件 (50Hz)
% 文件名明确标注为 52Hz (实际计算值) 或 50Hz (标称值)
save_filename = fullfile(outDir, 'stage_final_52Hz.dat');

fid_out = fopen(save_filename, 'wb');
if fid_out < 0
    error('无法创建文件 %s', save_filename);
end
fwrite(fid_out, final_data, 'double');
fclose(fid_out);

fprintf('\n🎉 全流程处理完成！');
fprintf('\n📁 最终文件已保存: %s', save_filename);
fprintf('\n📊 最终采样率: %.2f Hz (由 %.2f Hz / 4 得到)', Fs_final, Fs_current);
fprintf('\n📏 有效数据长度: %d 点\n', length(final_data));

%% 6. 绘图验证
figure('Name', '最终结果 (约52 Hz)', 'Color', 'w', 'Position', [100, 100, 800, 400]);
t_axis = (0 : length(final_data) - 1) / Fs_final;
plot(t_axis, final_data, 'r-', 'LineWidth', 1);
grid on;
title(sprintf('最终降采样结果 (Fs = %.2f Hz)', Fs_final));
xlabel('时间 (秒)');
ylabel('幅度');
xlim([0 10]); % 只显示前10秒
%% 1. 初始化与信号生成
clear; clc; close all;

% --- 参数设置 ---
Fs_in = 2000e3;       % 输入采样率: 2 MHz
DecimationFactor = 4;% 降采样因子
FilterOrder = 500;    % 滤波器阶数 (根据 MULTISPEED 定义)

% 计算无效点数量
% 滤波器需要填充 500 个输入点，每 10 个点输出 1 个
% 所以前 500/10 = 50 个输出点是“填充阶段”产生的，不可信
NumInvalidPoints = FilterOrder / DecimationFactor; 

Duration = 0.002;    % 信号时长: 0.2毫秒
t_in = (0 : 1/Fs_in : Duration-1/Fs_in)'; % 输入时间轴 (列向量)

% --- 生成叠加信号 ---
% 信号1: 20kHz (低频，应该被保留)
f1 = 20e3; 
sig1 = sin(2*pi * f1 * t_in);

% 信号2: 150kHz (高频，应该被滤除)
f2 = 150e3;
sig2 = 0.5 * sin(2*pi * f2 * t_in);

% 混合信号
x_input = sig1 + sig2;

%% 2. 调用滤波器 & 去除无效点
disp('🔍 正在运行滤波器并剔除无效点...');

% 调用 MULTISPEED 函数
y_full = dec_4(x_input);

% --- ⭐ 关键步骤：剔除前 50 个无效点 ---
y_valid = y_full(NumInvalidPoints + 1 : end);

% 生成对应的时间轴 (也要剔除对应的点)
% 注意：降采样后的时间轴间隔是 1/(Fs_in/10)
t_out_full = (0 : length(y_full)-1)' / (Fs_in/DecimationFactor);
t_out_valid = t_out_full(NumInvalidPoints + 1 : end);

%% 3. 长度验证与报告
len_in = length(x_input);
len_out_raw = length(y_full);
len_out_valid = length(y_valid);

% 理论长度 (去除无效点后)
% 输入 N 个点，前 500 个点用于填充，剩下 (N-500) 个点产生输出
% 输出点数约为 (N-500)/10
theoretical_valid_len = floor((len_in - FilterOrder) / DecimationFactor);

fprintf('==========================================\n');
fprintf('📊 滤波器输出验证报告\n');
fprintf('==========================================\n');
fprintf('输入总点数:      %d\n', len_in);
fprintf('原始输出点数:    %d (含前 %d 个无效点)\n', len_out_raw, NumInvalidPoints);
fprintf('清洗后有效点数:  %d\n', len_out_valid);
fprintf('理论有效点数:    %d\n', theoretical_valid_len);

if abs(len_out_valid - theoretical_valid_len) <= 1
    fprintf('✅ 长度检查通过：抽取比例正确 (10:1)。\n');
else
    fprintf('❌ 长度检查失败：点数异常。\n');
end
fprintf('==========================================\n');

%% 4. 绘图对比 (使用清洗后的数据)
figure('Color', 'w', 'Position', [100, 100, 1000, 600]);

% 时域对比
subplot(2, 1, 1);
% 绘制原始混合信号 (为了对比，只画前一部分)
plot(t_in*1e6, x_input, 'Color', [0.8 0.8 0.8], 'LineWidth', 1); 
hold on;
% 绘制清洗后的滤波信号 (红色点)
stem(t_out_valid*1e6, y_valid, 'r.', 'MarkerSize', 8);
title(['时域对比 (已剔除前 ' num2str(NumInvalidPoints) ' 个无效点)']);
xlabel('时间 (\mus)'); ylabel('幅度');
legend('原始混合信号 (灰色)', '滤波后有效信号 (红点)');
grid on;
xlim([0 1000]); % 只看前 100us

% 频域分析 (使用清洗后的数据)
subplot(2, 1, 2);
N_fft = 2^12;
Y_fft = fft(y_valid, N_fft);
Y_fft = abs(Y_fft(1:N_fft/2));
f_fft = (0:N_fft/2-1) * (Fs_in/DecimationFactor) / N_fft;

plot(f_fft/1e3, Y_fft, 'b', 'LineWidth', 1.5);
title('滤波后信号频谱 (有效数据)');
xlabel('频率 (kHz)'); ylabel('幅值');
grid on;
xlim([0 200]);
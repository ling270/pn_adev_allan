clc; clear; close all;

%% ===================== 1. 文件配置 =====================
baseDir = "datasource4\processed_phase_output";

ch12Files = {
    { fullfile(baseDir, "phase_fx12_st1.bin") };
    { fullfile(baseDir, "phase_fx12_st2.bin") };
    { fullfile(baseDir, "phase_fx12_st3.bin") };
};

ch34Files = {
    { fullfile(baseDir, "phase_fx34_st1.bin") };
    { fullfile(baseDir, "phase_fx34_st2.bin") };
    { fullfile(baseDir, "phase_fx34_st3.bin") };
};

NumStages = numel(ch12Files);

%% ===================== 2. 采样率 =====================
FS = 133e6;
CIC_R = 64;
Fs0 = FS / CIC_R;

FsList = [
    Fs0/10
    Fs0/100
    Fs0/1000
];

%% ===================== 3. 参数 =====================
StageRawConfig = [
    8192,  inf, 0;
    8192,  inf, 0;
    8192,  inf, 1;
];

low_cut_idx = 2;

Results.Auto  = cell(NumStages,1);
Results.Cross = cell(NumStages,1);

fprintf("\n--- 开始计算（流式 + 多文件平均）---\n");

%% ===================== 4. 主循环 =====================
for st = 1:NumStages

    fprintf('\n====== Stage %d ======\n', st);

    files12 = ch12Files{st};
    files34 = ch34Files{st};

    Fs = FsList(st);
    nfft = StageRawConfig(st,1);
    maxAvg = StageRawConfig(st,2);
    dtrend_mode = StageRawConfig(st,3);

    %% ===== 自谱（多文件 + 流式）=====
    [fA, LA, infoA] = read_phase_psd_multi( ...
        files12, Fs, nfft, maxAvg, low_cut_idx, dtrend_mode);

    %% ===== 互谱（多文件 + 流式）=====
    [fC, LC, infoC] = read_phase_cpsd_multi( ...
        files12, files34, Fs, nfft, low_cut_idx, dtrend_mode);

    Results.Auto{st} = struct('f',fA,'L',LA,'Avg',infoA.actual_avg);
    Results.Cross{st} = struct('f',fC,'L',LC,'Avg',infoC.actual_avg);

    fprintf('✅ Fs=%.1f Hz | AutoAvg=%d | CrossAvg=%d\n', ...
        Fs, infoA.actual_avg, infoC.actual_avg);
end

%% ===================== 5. 绘图 =====================
figure; hold on; grid on;
set(gcf, 'Color', 'w'); % 再设置背景颜色为白色
set(findall(gcf, '-property', 'FontName'), 'FontName', 'Times New Roman', 'FontSize', 12);
colors = lines(NumStages);

SmoothWin = 15;
UseMedian = true;

for st = 1:NumStages

    fA = Results.Auto{st}.f;
    LA = Results.Auto{st}.L;

    fC = Results.Cross{st}.f;
    LC = Results.Cross{st}.L;

    % ===== 平滑处理 =====
    if UseMedian
        LA_s = medfilt1(LA, SmoothWin);
        LC_s = medfilt1(LC, SmoothWin);
    else
        LA_s = smoothdata(LA, 'movmean', SmoothWin);
        LC_s = smoothdata(LC, 'movmean', SmoothWin);
    end

    % ===== 绘图 =====
    plot(fA, LA_s, 'Color',colors(st,:), 'LineWidth',1.5);
    plot(fC, LC_s, '--', 'Color',colors(st,:), 'LineWidth',1.5);

end

set(gca,'XScale','log');
xlabel('Frequency (Hz)');
ylabel('Phase Noise (dBc/Hz)');
title('Phase Noise (Smoothed)');
legend('Auto1','Cross1','Auto2','Cross2','Auto3','Cross3');

function [f_plot, L_plot, info] = read_phase_psd_multi(files, Fs, nfft, maxAvg, low_cut_idx, dtrend_mode)

win = hann(nfft,'periodic');
noverlap = nfft/2;
step = nfft - noverlap;

P_acc = 0;
total_avg = 0;

blockSize = step * 200;

for k = 1:length(files)

    fid = fopen(files{k},'rb');
    buffer = [];

    while ~feof(fid)

        data = fread(fid, blockSize, 'double');
        if isempty(data), break; end

        buffer = [buffer; data];

        while length(buffer) >= nfft

            seg = buffer(1:nfft);

            if dtrend_mode==0
                seg = detrend(seg,'linear');
            else
                seg = detrend(seg,'constant');
            end

            [Pxx,f] = periodogram(seg,win,nfft,Fs);

            P_acc = P_acc + Pxx;
            total_avg = total_avg + 1;

            buffer = buffer(step+1:end);

            if total_avg >= maxAvg, break; end
        end

        if total_avg >= maxAvg, break; end
    end

    fclose(fid);
end

P_mean = P_acc / total_avg;
L = 10*log10(P_mean/2);

mask = (f > f(low_cut_idx)) & (f < Fs*0.45);

f_plot = f(mask);
L_plot = L(mask);

info.actual_avg = total_avg;
end

function [f_plot, L_plot, info] = read_phase_cpsd_multi(filesA, filesB, Fs, nfft, low_cut_idx, dtrend_mode)

win = hann(nfft,'periodic');
noverlap = nfft/2;
step = nfft - noverlap;

P_acc = 0;
total_avg = 0;

blockSize = step * 200;

for k = 1:min(length(filesA), length(filesB))

    fidA = fopen(filesA{k},'rb');
    fidB = fopen(filesB{k},'rb');

    bufferA = [];
    bufferB = [];

    while ~feof(fidA) && ~feof(fidB)

        dataA = fread(fidA, blockSize, 'double');
        dataB = fread(fidB, blockSize, 'double');

        if isempty(dataA) || isempty(dataB), break; end

        bufferA = [bufferA; dataA];
        bufferB = [bufferB; dataB];

        while length(bufferA)>=nfft && length(bufferB)>=nfft

            segA = bufferA(1:nfft);
            segB = bufferB(1:nfft);

            if dtrend_mode==0
                segA = detrend(segA,'linear');
                segB = detrend(segB,'linear');
            else
                segA = detrend(segA,'constant');
                segB = detrend(segB,'constant');
            end

            [Pxy,f] = cpsd(segA,segB,win,noverlap,nfft,Fs);

            P_acc = P_acc + Pxy;
            total_avg = total_avg + 1;

            bufferA = bufferA(step+1:end);
            bufferB = bufferB(step+1:end);
        end
    end

    fclose(fidA);
    fclose(fidB);
end

P_mean = P_acc / total_avg;
L = 10*log10(abs(P_mean)/2);

mask = (f > f(low_cut_idx)) & (f < Fs*0.45);

f_plot = f(mask);
L_plot = L(mask);

info.actual_avg = total_avg;
end
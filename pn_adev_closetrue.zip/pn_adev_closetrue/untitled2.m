%% 1. 读取数据
filename = 'datasource4/df34_fx_7s_18s.dat';
fid = fopen(filename, 'rb');
if fid < 0
    error('无法打开文件 %s，请检查文件路径是否正确。', filename);
end

% 读取所有数据，格式为 'double'
raw_data = fread(fid, 'double');
fclose(fid);

% 确保是列向量
raw_data = raw_data(:);

fprintf('✅ 成功读取数据，原始长度: %d\n', length(raw_data));

%% 2. 级联降采样 (4次 x10 = 10,000倍)
% 原始采样率: 2,000,000 Hz (2 MHz)
% 目标采样率: 200 Hz
% 总降采样因子: 2,000,000 / 200 = 10,000
% MULTISPEED 每次降 10倍，所以需要调用 4 次

fprintf('正在执行多级降采样 (共4级，每级x10)...\n');

% 第1级: 2MHz -> 200kHz
y1 = MULTISPEED(raw_data);

% 第2级: 200kHz -> 20kHz
y2 = MULTISPEED(y1);

% 第3级: 20kHz -> 2kHz
y3 = MULTISPEED(y2);

% 第4级: 2kHz -> 200Hz (目标)
y_4 = MULTISPEED(y3);

y_final = dec_4(y4);

fprintf('降采样完成。最终采样率: 200 Hz\n');

%% 3. 去除无效点 (累积延迟)
% 简化算法：
% 输入端总延迟样本数 = 500/2 + 500/2*10 + 500/2*100 + 500/2*1000 ... (非常巨大)
% 输出端总延迟点数 = 总输入延迟 / 总降采样率
% 经验公式：每级贡献约 50 个最终输出点的延迟。
% 4级 * 50 = 200 个点。为了安全，我们去掉前 300 个点。

NumInvalidPoints = 300;

if length(y_final) > NumInvalidPoints
    y_valid = y_final(NumInvalidPoints + 1 : end);
    fprintf('已剔除前 %d 个累积无效点。\n', NumInvalidPoints);
else
    error('数据长度过短，无法进行4级降采样并剔除延迟。');
end

%% 4. 绘图
% 生成时间轴 (单位: 秒)
% 每个点的时间间隔 = 1 / 200 = 0.005秒
Fs_final = 200;
t = (0 : length(y_valid) - 1) / Fs_final;

figure('Name', '2MHz降至200Hz频率波动', 'Color', 'w', 'Position', [100, 100, 800, 600]);
plot(t, y_valid, 'b-', 'LineWidth', 1);
grid on;
title(['频率波动图 (原始 2MHz \rightarrow 最终 200Hz, 总降采样 10,000倍)']);
xlabel('时间 (秒)');
ylabel('频率 (Hz)');
legend('降采样后频率');

fprintf('✅ 绘图完成！数据总时长: %.2f 秒\n', t(end));
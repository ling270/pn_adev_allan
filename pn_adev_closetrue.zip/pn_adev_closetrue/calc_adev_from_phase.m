clc; clear; close all;

%% ===================== 参数 =====================

FS = 133e6;
CIC_R = 64;
Fs0 = FS / CIC_R; % 约 2.078 MHz

fs = Fs0/4e4;              % 采样率 (Hz)
f0 = 10e6;            % 标称频率 (Hz)

% 定义要去掉的前段时长
t_cut = 10;            % 单位：秒
cut_samples = round(t_cut * fs); % 需要剔除的样本点数

output_root = fullfile("E:", "pn_stage_temp", "adev_results");
if ~exist(output_root, 'dir')
    mkdir(output_root);
end

%% ===================== 文件1 =====================
file_1_path = fullfile("datasource4\decimated_results", "stage_final_52Hz.dat");
file_1_name = 'stage_final_52Hz';

fprintf('\n===== 文件1 =====\n');

if exist(file_1_path, 'file')

    fid = fopen(file_1_path, 'rb');
    phase_data_1 = fread(fid, 'double');
    fclose(fid);

    % 1. 计算瞬时相对频率 y(t)
    Ts = 1/fs;
    y_full = phase_data_1/ f0;
    
    % 2. === 数据截断处理 ===
    % 去掉前 cut_samples 个点，保留后面的数据
    y_1 = y_full(cut_samples+1:end);
    
    % 3. 计算 Allan 方差 (基于截断后的数据)
    [adev_1, tau_1] = adevCalcFunc(y_1, fs);

    % 4. 保存数据
    writematrix([tau_1, adev_1], ...
        fullfile(output_root, file_1_name + "_adev.csv"));

    % 5. 绘制 Allan 方差图
    figure(1');
    set(gcf, 'Color', 'w'); % 再设置背景颜色为白色
    loglog(tau_1, adev_1, 'b-', 'LineWidth', 1.5);
    grid on;
    title(['Allan Deviation']);
    xlabel('\tau (s)');
    ylabel('\sigma_y(\tau)');
        % --- 【修改点1】Allan 方差图上方留白 10% ---
    ylim_auto = ylim; % 获取当前自动计算的Y轴范围 [min, max]
    ylim([ylim_auto(1)*0.5, ylim_auto(2) * 2]); % 保持下限不变，上限变为原来的1.1倍

    % --- 【修改点2】强制设置字体为 Times New Roman ---
   set(findall(gcf, '-property', 'FontName'), 'FontName', 'Times New Roman', 'FontSize', 24);

    % ================= 新增：相对频率偏差绘图 =================
    % 生成对应的时间轴 (注意：y_1 是截断后的，但为了显示在原时间轴上，需要加偏移)
    % 原始 y_full 的时间轴是 0 到 end
    % y_1 对应的时间轴应该是从 t_cut 开始
    t_1 = (cut_samples : length(y_full)-1) * Ts;
    
    % 计算统计量 (基于截断后的数据 y_1)
    mean_y_1 = mean(y_1);       
    std_y_1 = std(y_1);         
    
    figure(3); 
    plot(t_1, y_1, 'b-', 'LineWidth', 0.8); hold on;
    yline(mean_y_1, 'r--', 'LineWidth', 1.5, 'Label', ['Mean: ' num2str(mean_y_1, '%.2e')]);
    yline(mean_y_1 + std_y_1, 'k:', 'LineWidth', 1, 'Label', '+1\sigma');
    yline(mean_y_1 - std_y_1, 'k:', 'LineWidth', 1, 'Label', '-1\sigma');
    
    grid on;
    title(['Relative Frequency Deviation - ' file_1_name ' (First 4s Removed)']);
    xlabel('Time (s)');
    ylabel('y(t) (Relative Freq. Deviation)');
    legend('Location', 'best');
    
    fprintf('  -> CH12 频率偏差均值: %.2e, 标准差: %.2e\n', mean_y_1, std_y_1);

end

%% ===================== 文件2 =====================
file_2_path = fullfile("datasource4\fx_stage", "ch34_stage_4_fx_1.bin");
file_2_name = 'ch34_stage_7_2';

fprintf('\n===== 文件2 =====\n');

if exist(file_2_path, 'file')

    fid = fopen(file_2_path, 'rb');
    phase_data_2 = fread(fid, 'double');
    fclose(fid);

    % 1. 计算瞬时相对频率 y(t)
    Ts = 1/fs;
    y_full = diff(phase_data_2) / (2*pi*f0*Ts);

    % 2. === 数据截断处理 ===
    y_2 = y_full(cut_samples+1:end);
    
    % 3. 计算 Allan 方差
    [adev_2, tau_2] = adevCalcFunc(y_2, fs);

    % 4. 保存数据
    writematrix([tau_2, adev_2], ...
        fullfile(output_root, file_2_name + "_adev.csv"));

    % 5. 绘制 Allan 方差图
    figure(2);
    loglog(tau_2, adev_2, 'r-', 'LineWidth', 1.5);
    grid on;
    title(['Allan Deviation - ' file_2_name ' (First 4s Removed)']);
    xlabel('\tau (s)');
    ylabel('\sigma_y(\tau)');
    % --- 在 figure(1) 到 figure(4) 的绘图代码后分别添加 ---
    set(findall(gcf, '-property', 'FontName'), 'FontName', 'Times New Roman');
    % ================= 新增：相对频率偏差绘图 =================
    % 生成时间轴
    t_2 = (cut_samples : length(y_full)-1) * Ts;
    
    % 计算统计量
    mean_y_2 = mean(y_2);
    std_y_2 = std(y_2);
    
    figure(4); 
    plot(t_2, y_2, 'r-', 'LineWidth', 0.8); hold on;
    yline(mean_y_2, 'b--', 'LineWidth', 1.5, 'Label', ['Mean: ' num2str(mean_y_2, '%.2e')]);
    yline(mean_y_2 + std_y_2, 'k:', 'LineWidth', 1, 'Label', '+1\sigma');
    yline(mean_y_2 - std_y_2, 'k:', 'LineWidth', 1, 'Label', '-1\sigma');
    
    grid on;
    title(['Relative Frequency Deviation - ' file_2_name ' (First 4s Removed)']);
    xlabel('Time (s)');
    ylabel('y(t) (Relative Freq. Deviation)');
    legend('Location', 'best');
    % --- 在 figure(1) 到 figure(4) 的绘图代码后分别添加 ---
    set(findall(gcf, '-property', 'FontName'), 'FontName', 'Times New Roman');
    fprintf('  -> CH34 频率偏差均值: %.2e, 标准差: %.2e\n', mean_y_2, std_y_2);

end

fprintf('\n✔ 完成（已去除前4秒数据）\n');
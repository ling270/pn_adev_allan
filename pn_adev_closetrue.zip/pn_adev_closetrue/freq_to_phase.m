clc; clear; close all;

%% ===================== 1. 基础配置 =====================
baseDir = "datasource4\decimated_results"; % 输入文件夹
outputDir = "datasource4\processed_phase_output";      % 输出文件夹

% 自动创建输出文件夹
if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end

% 系统时钟参数
FS = 133e6;
CIC_R = 64;
Fs0 = FS / CIC_R; % ~2.078 MHz

%% ===================== 2. 任务列表配置 =====================
% 每一行代表一个任务：{ '输入文件名', '输出文件名', 采样率, 去趋势模式 }
% 去趋势模式: 0 = 'linear' (去线性), 1 = 'constant' (去直流)
JobList = {
    % --- Stage 1 (高频) ---
    { 'fx12_stage_1_207812Hz.dat', 'phase_fx12_st1.bin', Fs0/10,   0 };
    { 'fx34_stage_1_207812Hz.dat', 'phase_fx34_st1.bin', Fs0/10,   0 };
    
    % --- Stage 2 (中频) ---
    { 'fx12_stage_2_20781Hz.dat',  'phase_fx12_st2.bin', Fs0/100,  0 };
    { 'fx34_stage_2_20781Hz.dat',  'phase_fx34_st2.bin', Fs0/100,  0 };
    
    % --- Stage 3 (低频) ---
    { 'fx12_stage_3_2078Hz.dat',   'phase_fx12_st3.bin', Fs0/1000, 1 }; % 注意：这里用了 1 (constant)
    { 'fx34_stage_3_2078Hz.dat',   'phase_fx34_st3.bin', Fs0/1000, 1 };
};

%% ===================== 3. 执行循环 =====================
fprintf('\n--- 开始批量调用 analyze_freq_to_phase ---\n');

for i = 1:size(JobList, 1)
    % 1. 提取参数
    inName  = JobList{i}{1};
    outName = JobList{i}{2};
    Fs_val  = JobList{i}{3};
    mode    = JobList{i}{4};
    
    % 2. 拼接完整路径
    input_path  = fullfile(baseDir, inName);
    output_path = fullfile(outputDir, outName);
    
    % 3. 检查文件是否存在
    if ~exist(input_path, 'file')
        fprintf('⚠️ 跳过 (文件不存在): %s\n', inName);
        continue;
    end
    
    % 4. 调用核心函数
    try
        % === 这里调用你提供的函数 ===
        phase_data = analyze_freq_to_phase(input_path, output_path, Fs_val, mode);
        
        fprintf('✅ 处理成功: %s\n', inName);
        
    catch ME
        fprintf('❌ 处理失败: %s - 错误: %s\n', inName, ME.message);
    end
end

fprintf('\n🎉 所有任务执行完毕。\n');
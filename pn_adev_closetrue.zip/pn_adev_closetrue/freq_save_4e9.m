clc; clear; close all;

%% ===================== 1. 参数 =====================
filePath = "10_FDR_two_10M_Ref_10M_DUT_20260420_172800.dat";

FS = 133000000;
CIC_R = 64;
Fs_base = FS / CIC_R; % 2,078,125 Hz

% ⭐ 修改点 1：定义时间窗口
time_start =4;   % 开始时间 (秒)
time_end   = 150;  % 结束时间 (秒)

% 计算对应的采样点索引 (从1开始计数)
start_sample_idx = time_start * Fs_base + 1; 
end_sample_idx   = time_end * Fs_base;

% 设置处理上限为第18秒，避免读取无用数据
maxFrames = end_sample_idx; 

% 设置跳过量为前7秒
skipSamples = start_sample_idx - 1; 

% 绘图帧数（可选，设为0则不绘图，仅保存文件，或者设为一个小值预览）
plotFrames = 100000000; % 仅预览前10000点，或者设为0跳过绘图

chunkInt32 = 20000000;
chunkInt32 = floor(chunkInt32/4)*4;

outDir = "datasource4";
if ~exist(outDir,'dir'), mkdir(outDir); end

df12_file = fullfile(outDir,"df12_10Hz.dat"); % 修改文件名以示区分
df34_file = fullfile(outDir,"df34_10Hz.dat");

%% ===================== 2. 文件信息 =====================
fid = fopen(filePath,"rb");
if fid < 0, error("无法打开文件"); end

fseek(fid,0,"eof");
totalInt32 = floor((ftell(fid)/4)/4)*4;
totalFrames = totalInt32/4;
fseek(fid,0,"bof");

fprintf("总帧数: %d\n", totalFrames);
fprintf("本次处理范围: %d 到 %d 点\n", start_sample_idx, end_sample_idx);
fprintf("跳过前 %.1f 秒 (%d 点)\n", time_start, skipSamples);

%% ===================== 3. 第一遍（绘图 - 可选） =====================
% 如果不需要绘图，可以将 plotFrames 设为 0，这里为了演示保留结构
nKeep = min(plotFrames, maxFrames);

df12_plot = zeros(nKeep,1);
df34_plot = zeros(nKeep,1);

done = 0; 
kept = 0;
tprint=tic;

while ~feof(fid)
    if done >= maxFrames, break; end

    raw = fread(fid, chunkInt32, "int32=>int32", 0, "b");
    if isempty(raw), break; end

    n = floor(numel(raw)/4)*4;
    raw = raw(1:n);

    B1 = swapbytes(reshape(raw,1,[]));
    CC = reshape(B1,4,[]);
    M = size(CC,2);

    if done + M > maxFrames
        M = maxFrames - done;
        CC = CC(:,1:M);
    end

    CH1 = double(CC(4,:))'/(2^32)*Fs_base;
    CH2 = double(CC(3,:))'/(2^32)*Fs_base;
    CH3 = double(CC(2,:))'/(2^32)*Fs_base;
    CH4 = double(CC(1,:))'/(2^32)*Fs_base;
    % 
    % df12 = CH2 - CH1;
    % df34 = CH3 - CH4;

    df12 = CH1 - CH2;
    df34 = CH4 - CH3;

    %% 跳过前 7 秒
    startIdx = 1;
    if done < skipSamples
        if done + M <= skipSamples
            done = done + M;
            continue;
        else
            startIdx = skipSamples - done + 1;
        end
    end

    validLen = M - startIdx + 1;

    %% 保存绘图数据
    if kept < nKeep
        take = min(validLen, nKeep - kept);
        df12_plot(kept+1:kept+take) = df12(startIdx:startIdx+take-1);
        df34_plot(kept+1:kept+take) = df34(startIdx:startIdx+take-1);
    end

    kept = kept + validLen;
    done = done + M;
    
    % 进度显示
    if toc(tprint) > 1
        fprintf("进度: %.2f%%\n", 100*done/maxFrames);
        tprint = tic;
    end
end
fclose(fid);

%% ===================== 4. 第二遍：写文件 =====================
% 重新打开文件进行第二次读取
fid = fopen(filePath,"rb");
fd12 = fopen(df12_file,"wb");
fd34 = fopen(df34_file,"wb");

done = 0; 
kept = 0;
tprint=tic;

while ~feof(fid)
    if done >= maxFrames, break; end

    raw = fread(fid, chunkInt32, "int32=>int32", 0, "b");
    if isempty(raw), break; end

    n = floor(numel(raw)/4)*4;
    raw = raw(1:n);

    B1 = swapbytes(reshape(raw,1,[]));
    CC = reshape(B1,4,[]);
    M = size(CC,2);

    if done + M > maxFrames
        M = maxFrames - done;
        CC = CC(:,1:M);
    end

    CH1 = double(CC(4,:))'/(2^32)*Fs_base;
    CH2 = double(CC(3,:))'/(2^32)*Fs_base;
    CH3 = double(CC(2,:))'/(2^32)*Fs_base;
    CH4 = double(CC(1,:))'/(2^32)*Fs_base;

    df12 = CH2 - CH1;
    df34 = CH3 - CH4;

    %% ⭐ 跳过前 7 秒
    startIdx = 1;
    if done < skipSamples
        if done + M <= skipSamples
            done = done + M;
            continue;
        else
            startIdx = skipSamples - done + 1;
        end
    end

    %% ===== 写入文件 =====
    % 只写入从 startIdx 到末尾的数据（即 7s 到 18s）
    fwrite(fd12, df12(startIdx:end), "double");
    fwrite(fd34, df34(startIdx:end), "double");

    kept = kept + (M - startIdx + 1);
    done = done + M;

    if toc(tprint) > 1
        fprintf("写入进度: %.2f%%\n", 100*done/maxFrames);
        tprint = tic;
    end
end

fclose(fid); 
fclose(fd12); 
fclose(fd34);

%% ===================== 5. 绘图验证 =====================
% 生成对应的时间轴 (从 7秒 开始)
tt = ((1:length(df12_plot))' - 1) / Fs_base + time_start;

figure;
subplot(2,1,1);
plot(tt, df12_plot); grid on;
title(['CH2 - CH1 频率差 (', num2str(time_start), 's - ', num2str(time_end), 's)']);
xlabel('时间 (s)');

subplot(2,1,2);
plot(tt, df34_plot); grid on;
title(['CH3 - CH4 频率差 (', num2str(time_start), 's - ', num2str(time_end), 's)']);
xlabel('时间 (s)');

fprintf("\n✅ 完成！\n");
fprintf("保存区间: %ds - %ds\n", time_start, time_end);
fprintf("有效数据点: %.2e\n", kept);
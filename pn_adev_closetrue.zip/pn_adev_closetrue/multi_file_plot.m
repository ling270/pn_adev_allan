clc; clear; close all;

%% ===================== 1. 加载数据 =====================
dataFile = 'pn_avg_results_pro.mat';

if ~exist(dataFile, 'file')
    error('未找到数据文件 %s', dataFile);
end

data = load(dataFile);
Results = data.Results;

NumStages = length(Results.Auto);

% 颜色定义
colors = lines(NumStages);

fprintf('加载完成，共 %d 个Stage\n', NumStages);

%% ===================== 2. 初始化 Figure =====================

% --- Figure 1: Auto Only (仅自谱) ---
figure(1); clf;
ax1 = axes; hold(ax1, 'on'); grid(ax1, 'on'); box(ax1, 'on');
set(ax1, 'XScale', 'log');
xlabel(ax1, 'Offset Frequency (Hz)');
ylabel(ax1, 'Phase Noise (dBc/Hz)');
title(ax1, 'Phase Noise - Auto Spectrum');
hAuto_Solo = gobjects(NumStages, 1);
legNames_Auto = cell(NumStages, 1);
ylim_min_Auto = inf; ylim_max_Auto = -inf;

% --- Figure 2: Cross Only (仅互谱) ---
figure(2); clf;
ax2 = axes; hold(ax2, 'on'); grid(ax2, 'on'); box(ax2, 'on');
set(ax2, 'XScale', 'log');
xlabel(ax2, 'Offset Frequency (Hz)');
ylabel(ax2, 'Phase Noise (dBc/Hz)');
title(ax2, 'Phase Noise - Cross Spectrum');
hCross_Solo = gobjects(NumStages, 1);
legNames_Cross = cell(NumStages, 1);
ylim_min_Cross = inf; ylim_max_Cross = -inf;

% --- Figure 3: Combined (自谱+互谱混合) ---
figure(3); clf;
ax3 = axes; hold(ax3, 'on'); grid(ax3, 'on'); box(ax3, 'on');
set(ax3, 'XScale', 'log');
xlabel(ax3, 'Offset Frequency (Hz)');
ylabel(ax3, 'Phase Noise (dBc/Hz)');
title(ax3, 'Phase Noise (Auto vs Cross)');
hAuto_Comb = gobjects(NumStages, 1);
hCross_Comb = gobjects(NumStages, 1);
legNames_Comb = cell(2*NumStages, 1);
ylim_min_Comb = inf; ylim_max_Comb = -inf;

%% ===================== 3. 主绘图循环 =====================
for i = 1:NumStages
    A = Results.Auto{i};
    C = Results.Cross{i};

    fA = A.f;  LA = A.L_raw;
    fC = C.f;  LC = C.L_raw;

    %% ===== 后处理 =====
    if isfield(Results,'Params')
        pConfig = Results.Params(i,:);
        params.SpurThreshold = pConfig(3);
        params.SpurRatio     = pConfig(4);
        params.SmoothWindow  = pConfig(5);

        try
            LA = pn_post_processing(fA, LA, params);
            LC = pn_post_processing(fC, LC, params);
        catch
        end
    end

    %% ===== 数据清洗 =====
    LA(LA < -250) = NaN;
    LC(LC < -250) = NaN;

    %% ===== 绘图 Figure 1 (Auto) =====
    hAuto_Solo(i) = plot(ax1, fA, LA, '-', ...
        'Color', colors(i,:), 'LineWidth', 1.5);
    legNames_Auto{i} = sprintf('St%d Auto', i);
    ylim_min_Auto = min([ylim_min_Auto; LA(:)], [], 'omitnan');
    ylim_max_Auto = max([ylim_max_Auto; LA(:)], [], 'omitnan');

    %% ===== 绘图 Figure 2 (Cross) =====
    hCross_Solo(i) = plot(ax2, fC, LC, '--', ...
        'Color', colors(i,:), 'LineWidth', 1.5);
    legNames_Cross{i} = sprintf('St%d Cross (Avg=%d)', i, C.Avg);
    ylim_min_Cross = min([ylim_min_Cross; LC(:)], [], 'omitnan');
    ylim_max_Cross = max([ylim_max_Cross; LC(:)], [], 'omitnan');

    %% ===== 绘图 Figure 3 (Combined) =====
    hAuto_Comb(i) = plot(ax3, fA, LA, '-', ...
        'Color', colors(i,:), 'LineWidth', 1.5);
    hCross_Comb(i) = plot(ax3, fC, LC, '--', ...
        'Color', colors(i,:), 'LineWidth', 1.5);
    legNames_Comb{2*i-1} = sprintf('St%d Auto', i);
    legNames_Comb{2*i}   = sprintf('St%d Cross (Avg=%d)', i, C.Avg);
    ylim_min_Comb = min([ylim_min_Comb; LA(:); LC(:)], [], 'omitnan');
    ylim_max_Comb = max([ylim_max_Comb; LA(:); LC(:)], [], 'omitnan');
end

%% ===================== 4. 设置坐标轴范围与图例 =====================

% --- 通用 X 轴范围 ---
f_all = [];
for i = 1:NumStages
    f_all = [f_all; Results.Auto{i}.f(:)];
end
xlim_auto = [1, max(f_all)];

% --- 辅助函数句柄 (用于设置范围和图例) ---
setPlotLimits = @(ax, y_min, y_max) setAxisLimits(ax, y_min, y_max, xlim_auto);

% --- 应用 Figure 1 设置 ---
setPlotLimits(ax1, ylim_min_Auto, ylim_max_Auto);
legend(ax1, hAuto_Solo, legNames_Auto, 'Location', 'northeast', 'FontSize', 9);

% --- 应用 Figure 2 设置 ---
setPlotLimits(ax2, ylim_min_Cross, ylim_max_Cross);
legend(ax2, hCross_Solo, legNames_Cross, 'Location', 'northeast', 'FontSize', 9);

% --- 应用 Figure 3 设置 ---
setPlotLimits(ax3, ylim_min_Comb, ylim_max_Comb);
legend(ax3, [hAuto_Comb; hCross_Comb], legNames_Comb, 'Location', 'northeast', 'FontSize', 9);

fprintf('绘图完成：已生成 Auto、Cross 及 Combined 三张图。\n');

%% ===================== 子函数 =====================

% 局部函数：设置坐标轴范围
function setAxisLimits(ax, ymin, ymax, xl)
    xlim(ax, xl);
    if isfinite(ymin) && isfinite(ymax)
        range = ymax - ymin;
        ylim(ax, [ymin-0.1*range, ymax+0.1*range]);
    else
        ylim(ax, [-180 -60]);
    end
end

function [L_processed, spur_indices] = pn_post_processing(f, L_raw, params)
    p = inputParser;
    addParameter(p, 'SpurThreshold', -80);
    addParameter(p, 'SpurRatio', 3);
    addParameter(p, 'SmoothWindow', 11);
    addParameter(p, 'JitterRange', []);
    parse(p, params);

    L_out = L_raw;
    spur_indices = [];

    floor_limit = -180;
    L_out(L_out < floor_limit) = NaN;

    if params.SpurRatio > 0
        L_out = suppress_spurs_interp(L_out, params.SpurThreshold, params.SpurRatio);
    end

    if params.SmoothWindow > 1
        L_out = smooth_data(L_out, params.SmoothWindow);
    end
    
    try
        L_out(L_out < floor_limit) = NaN;
    catch
    end

    L_processed = L_out;
end

function L_clean = suppress_spurs_interp(L, thresh_dB, ratio)
    L_clean = L;
    len = length(L);
    if len < 5, return; end
    
    spur_idx = [];
    
    for i = 3 : len-2
        if ~isnan(L(i))
            local_window = L([i-2, i-1, i+1, i+2]);
            local_window = local_window(~isnan(local_window));
            
            if ~isempty(local_window)
                local_median = median(local_window);
                if (L(i) > local_median + ratio) && (L(i) > thresh_dB)
                    spur_idx = [spur_idx, i];
                end
            end
        end
    end
    
    if ~isempty(spur_idx)
        L_temp = L_clean;
        L_temp(spur_idx) = NaN;
        L_clean = fillmissing(L_temp, 'linear'); 
    end
end

function L_smooth = smooth_data(L, win_size)
    if mod(win_size, 2) == 0, win_size = win_size + 1; end
    L_smooth = movmedian(L, win_size, 'omitnan');
end
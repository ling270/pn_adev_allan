clc; clear; close all;

%% ===================== 1. 参数设置 =====================
filePath = fullfile("datasource4", "same_decimated_results", "stage_final_52Hz.dat");

% 采样率参数
FS = 133e6;             % 主时钟
CIC_R = 64;             % CIC 抽取
Fs = FS / CIC_R / 4e4;  % 最终采样率 (约 51.95 Hz)
f0 = 10e6;              % 标称频率 10MHz

% 截断设置
t_cut = 40;             % 去除前 100 秒
cut_samples = round(t_cut * Fs);

%% ===================== 2. 数据读取与处理 =====================
if ~exist(filePath, 'file')
    error('文件未找到: %s', filePath);
end

% 读取数据 (频率波动数据)
fid = fopen(filePath, 'rb');
raw_data = fread(fid, 'double');
fclose(fid);

% 截断数据
if length(raw_data) <= cut_samples
    error('数据长度不足，无法去除前 %d 秒。', t_cut);
end
data = raw_data(cut_samples + 1:end);

% --- 定义变量 y 为绝对频率偏差 (Hz) ---
% 注意：这里 y 代表的是 delta_f (Hz)，而不是相对偏差 y(t)
y = -data/f0; 

% 计算相位 (积分)
Ts = 1 / Fs;
% 相位 = 2*pi * 积分(频率偏差)
% 注意：这里使用的是 Hz 单位的频率偏差，计算出的相位是真实的相位波动
phase_rad = cumsum(y) * 2 * pi * Ts;

% 去趋势相位
phase_detrend = detrend(phase_rad);

% 生成时间轴
t = (0:length(y)-1)' * Ts;

%% ===================== 3. 绘图 =====================

% --- 图1：绝对频率偏差 ---
figure('Name', 'A Frequency Deviation', 'Color', 'w', 'Position', [100, 100, 800, 400]);
plot(t, y, 'b-', 'LineWidth', 1);
grid on;
% 修改标题和标签
title('Relative Frequency Fluctuation '); 
xlabel('Time (s)');
ylabel('Relative Frequency Deviation '); % 修改单位

% 设置字体
set(findall(gcf, '-property', 'FontName'), 'FontName', 'Times New Roman', 'FontSize', 24);

% 自动调整 Y 轴范围（留 10% 边距）
ylim_auto = ylim;
y_range = ylim_auto(2) - ylim_auto(1);
margin = y_range * 0.1; 
ylim([ylim_auto(1) - margin, ylim_auto(2) + margin]);


% --- 图2：相位波动 ---
figure('Name', 'Phase Fluctuation', 'Color', 'w', 'Position', [100, 100, 800, 400]);
plot(t, phase_rad, 'b-', 'LineWidth', 1);
grid on;
title('Relative Phase Fluctuation');
xlabel('Time (s)');
ylabel('Relative Phase(rad)');
set(findall(gcf, '-property', 'FontName'), 'FontName', 'Times New Roman', 'FontSize', 24);


% --- 图3：去趋势相位波动 ---
figure('Name', 'Phase', 'Color', 'w', 'Position', [100, 100, 800, 400]);
plot(t, phase_detrend, 'b-', 'LineWidth', 1);
grid on;
title('Relative phase Fluctuation');
xlabel('Time (s)');
ylabel('Relative Phase(rad)');
set(findall(gcf, '-property', 'FontName'), 'FontName', 'Times New Roman', 'FontSize', 24);

%% ===================== 4. 输出信息 =====================
fprintf('✅ 绘图完成。\n');
fprintf('采样率: %.4f Hz\n', Fs);
fprintf('数据点数: %d\n', length(y));
% 修改打印信息以匹配绝对频率
fprintf('频率偏差均值 (Hz): %.4f Hz\n', mean(y)); 
fprintf('频率偏差标准差 (Hz): %.4f Hz\n', std(y)); 
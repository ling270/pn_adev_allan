function pn_plotter(f, L_auto, L_cross, params)
% PN_PLOTTER 相位噪声绘图函数

    % --- 1. 参数解析 ---
    p = inputParser;
    addParameter(p, 'Title', 'Multi-stage Phase Noise Analysis');
    addParameter(p, 'ShowGrid', true);
    parse(p, params);

    % --- 2. 【修复】绘图前预处理：清洗底线数据 ---
    % 将小于 -250 的数值（包括刚才填充的 -300 或计算溢出的极小值）强制转换为 NaN
    % 这样 plot 函数遇到这些点会自动断点不画，彻底消除“底线”
    L_auto(L_auto < -250) = NaN;
    L_cross(L_cross < -250) = NaN;

    % --- 3. 绘图 ---
    figure('Name', 'Phase Noise Plot', 'Color', 'w');
    hold on; grid on; box on;

    % 绘制 Auto 曲线 (实线)
    h1 = plot(f, L_auto, 'LineWidth', 1.2);
    
    % 绘制 Cross 曲线 (虚线)
    h2 = plot(f, L_cross, '--', 'LineWidth', 1.2);

    % --- 4. 格式化 ---
    set(gca, 'XScale', 'log'); % X轴对数坐标
    % set(gca, 'YScale', 'log'); % 注意：相位噪声 dBc/Hz 通常 Y 轴是线性的 dB，不是对数
    
    xlabel('Frequency Offset (Hz)');
    ylabel('Phase Noise (dBc/Hz)');
    title(params.Title);

    % 【修复】锁定坐标轴范围
    % 防止自动缩放时因为极值（如残留的-300）把图像压缩得看不清
    % 典型的相位噪声关注范围通常在 -60 到 -160 dBc/Hz 之间
    ylim([-180, -100]); 
    
    % 图例（需要根据你的实际输入参数调整，这里假设有简单的图例）
    % legend([h1, h2], {'Auto Spectrum', 'Cross Spectrum'}, 'Location', 'SouthWest');

    hold off;
end
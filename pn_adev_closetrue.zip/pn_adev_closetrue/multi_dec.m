clc; clear; close all;

%% 1. 读取数据
filename = 'datasource4/df12_same.dat';
fid = fopen(filename, 'rb');
if fid < 0
    error('无法打开文件 %s，请检查文件路径是否正确。', filename);
end

% 读取所有数据，格式为 'double'
raw_data = fread(fid, 'double');
fclose(fid);

% 确保是列向量
raw_data = raw_data(:);
fprintf('✅ 成功读取数据，原始长度: %d\n', length(raw_data));

%% 2. 参数设置
% 原始采样率
FS = 133000000;
CIC_R = 64;
Fs_base = FS / CIC_R; % 2,078,125 Hz

Fs_start = Fs_base; % 根据上一段代码计算得出 (133M/64)
% 目标采样率
Fs_target = 200;
% 降采样因子
DecFactor = 10;
% 总级数
TotalStages = 4;

% 每一级要剔除的无效点数 (根据之前的讨论，每级剔除300点)
PointsToTrim = 300;

% 创建输出目录
outDir = 'datasource4/decimated_results';
if ~exist(outDir, 'dir')
    mkdir(outDir);
end

%% 3. 级联处理流水线
current_data = raw_data;
current_fs = Fs_start;

fprintf('开始级联降采样...\n');

for i = 1:TotalStages
    fprintf('正在处理第 %d 级 (Fs: %g -> %g Hz)...\n', i, current_fs, current_fs/DecFactor);
    
    % --- 执行降采样 ---
    y_filtered = MULTISPEED(current_data);
    
    % --- 剔除无效点 ---
    if length(y_filtered) > PointsToTrim
        y_valid = y_filtered(PointsToTrim + 1 : end);
    else
        error('第 %d 级处理后数据过短，无法剔除无效点。', i);
    end
    
    % --- 更新参数 ---
    current_data = y_valid;
    current_fs = current_fs / DecFactor;
    
    % --- 保存文件 ---
    % 文件名格式: stage_1_207812Hz.dat, stage_2_20781Hz.dat ...
    save_filename = fullfile(outDir, sprintf('stage_%d_%.0fHz.dat', i, current_fs));
    fid_out = fopen(save_filename, 'wb');
    fwrite(fid_out, current_data, 'double');
    fclose(fid_out);
    fprintf('   -> 已保存至 %s (长度: %d)\n', save_filename, length(current_data));
    
    % --- 绘制波形 ---
    figure('Name', sprintf('第%d级降采样结果 (%.0f Hz)', i, current_fs), 'Color', 'w', 'Position', [100, 100, 800, 400]);
    
    % 生成时间轴 (秒)
    t_axis = (0 : length(current_data) - 1) / current_fs;
    
    plot(t_axis, current_data, 'b-', 'LineWidth', 0.8);
    grid on;
    title(sprintf('第 %d 级降采样后频率波动 (Fs = %.0f Hz)', i, current_fs));
    xlabel('时间 (秒)');
    ylabel('频率 (Hz)');
    
    % 限制X轴显示范围，避免数据太长看不清细节 (例如只显示前5秒)
    if t_axis(end) > 5
        xlim([0 5]); 
    end
end

fprintf('\n✅ 所有级别处理完成！结果已保存在 %s\n', outDir);


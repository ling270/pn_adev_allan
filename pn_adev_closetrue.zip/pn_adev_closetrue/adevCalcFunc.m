function [adev, tau] = adevCalcFunc(y, fs)
% 增强版：支持自定义高密度 tau（仍使用 allanvar）

    N = length(y);
    Ts = 1/fs;

    %% ===================== 自定义 tau（核心修改） =====================
    % 👉 比 octave / decade 更密
    m_custom = unique(round(logspace(0, log10(N/10), 80)));  % ⭐关键

    % 限制范围
    m_custom = m_custom(m_custom >= 1 & 2*m_custom < N);

    %% ===================== 调用 allanvar =====================
    % 注意：这里直接传 m（samples）
    [avar_custom, tau_custom] = allanvar(y, m_custom, fs);

    %% ===================== 原始 octave + decade（保留） =====================
    [avar1, tau1] = allanvar(y, 'octave', fs);
    [avar2, tau2] = allanvar(y, 'decade', fs);

    %% ===================== 合并 =====================
    tau_all = [tau1(:); tau2(:); tau_custom(:)];
    avar_all = [avar1(:); avar2(:); avar_custom(:)];

    %% ===================== 排序 =====================
    [tau, idx] = sort(tau_all);
    avar = avar_all(idx);

    %% ===================== 去重（关键，不然会重叠） =====================
    [tau, unique_idx] = unique(tau);
    avar = avar(unique_idx);

    %% ===================== Allan deviation =====================
    adev = sqrt(avar);

end















clc; clear; close all;

%% ===================== 1. 文件列表配置 =====================
% 修改点：指向之前输出相位文件的文件夹
baseDir = "datasource4\processed_phase_output";

% 通道 12 文件列表 (对应之前生成的相位文件)
ch12Files = {
    { fullfile(baseDir, "phase_fx12_st1.bin") }; % Stage 1
    { fullfile(baseDir, "phase_fx12_st2.bin") }; % Stage 2
    { fullfile(baseDir, "phase_fx12_st3.bin") }; % Stage 3
};

% 通道 34 文件列表 (对应之前生成的相位文件)
ch34Files = {
    { fullfile(baseDir, "phase_fx34_st1.bin") }; % Stage 1
    { fullfile(baseDir, "phase_fx34_st2.bin") }; % Stage 2
    { fullfile(baseDir, "phase_fx34_st3.bin") }; % Stage 3
};

NumStages = numel(ch12Files);

%% ===================== 2. 采样率配置 =====================
FS = 133e6;
CIC_R = 64;
Fs0 = FS / CIC_R; % 约 2.078 MHz

% 每一级对应的实际采样率 (必须与生成相位文件时一致)
FsList = [
    Fs0/10;     % Stage 1: ~207.8 kHz
    Fs0/100;    % Stage 2: ~20.7 kHz
    Fs0/1000;   % Stage 3: ~2.07 kHz
];

%% ===================== 3. 处理参数配置 =====================
% 列定义: [nfft, maxAvg, detrend_mode]
% 注意：这里 dtrend_mode 依然保留，用于在计算谱之前对相位再次去趋势
StageRawConfig = [
    % nfft,  maxAvg,  dtrend_mode
    8192,    100,     0;   % Stage 1
    8192,    100,     0;   % Stage 2
    8192,    100,     1;   % Stage 3
];

low_cut_idx = 2; % 频率筛选起始索引

%% ===================== 4. 初始化结果结构体 =====================
% 修复了之前的初始化错误，确保字段是空的元胞数组
Spectra.CH12.f = {};
Spectra.CH12.L = {};
Spectra.CH12.Fs = {};

Spectra.CH34.f = {};
Spectra.CH34.L = {};
Spectra.CH34.Fs = {};

Results.Auto  = cell(NumStages, 1);
Results.Cross = cell(NumStages, 1);
Results.Params = StageRawConfig;

fprintf("\n--- 开始计算 (直接读取相位文件) ---\n");

%% ===================== 5. 主循环 =====================
for st = 1:NumStages

    fprintf('\n====== 处理 Stage %d ======\n', st);

    files12 = ch12Files{st};
    files34 = ch34Files{st};

    % 安全检查
    if st > length(FsList)
        error('FsList 数据不足，请补充第 %d 个采样率', st);
    end

    CurrentFs = FsList(st);
    nfft = StageRawConfig(st, 1);
    maxAvg = StageRawConfig(st, 2);
    dtrend_mode = StageRawConfig(st, 3);

    %% ===== 自谱计算 (直接读取相位) =====
    [fA, LA, infoA] = read_phase_psd( ...
        files12{1}, CurrentFs, nfft, maxAvg, low_cut_idx, dtrend_mode);

    %% ===== 互谱计算 (直接读取相位) =====
    [fC, LC, infoC] = read_phase_cpsd( ...
        files12, files34, CurrentFs, nfft, low_cut_idx, dtrend_mode);

    %% ===== 保存结果到结构体 =====
    Results.Auto{st} = struct( ...
        'f', fA, ...
        'L_raw', LA, ...
        'Avg', infoA.actual_avg, ...
        'Label', sprintf('Auto St%d', st));

    Results.Cross{st} = struct( ...
        'f', fC, ...
        'L_raw', LC, ...
        'Avg', infoC.actual_avg, ...
        'Label', sprintf('Cross St%d', st));

    % --- 修复点：同时也填充到 Spectra 结构体中 ---
    % 使用 contains 函数代替不安全的字符串索引
    if contains(files12{1}, 'fx12')
        % 填充 CH12
        idx_end = length(Spectra.CH12.f) + 1;
        Spectra.CH12.f{idx_end} = fA;
        Spectra.CH12.L{idx_end} = LA;
        Spectra.CH12.Fs{idx_end} = CurrentFs;
    elseif contains(files12{1}, 'fx34')
        % 填充 CH34
        idx_end = length(Spectra.CH34.f) + 1;
        Spectra.CH34.f{idx_end} = fA;
        Spectra.CH34.L{idx_end} = LA;
        Spectra.CH34.Fs{idx_end} = CurrentFs;
    end

    fprintf('✅ Stage %d 完成 | Fs=%.1f Hz | Auto Avg=%d | Cross Avg=%d\n', ...
        st, CurrentFs, infoA.actual_avg, infoC.actual_avg);
end

%% ===================== 6. 数据平滑处理 =====================
SmoothWindow = 15;
UseMedian = true;

fprintf('正在对数据进行平滑处理 (窗口=%d)...\n', SmoothWindow);

for st = 1:NumStages
    % --- 处理自谱 ---
    if ~isempty(Results.Auto{st}.L_raw)
        y = Results.Auto{st}.L_raw;
        if UseMedian
            y_smooth = medfilt1(y, SmoothWindow);
        else
            y_smooth = smoothdata(y, 'movmean', SmoothWindow);
        end
        Results.Auto{st}.L_smooth = y_smooth;
    end

    % --- 处理互谱 ---
    if ~isempty(Results.Cross{st}.L_raw)
        y = Results.Cross{st}.L_raw;
        if UseMedian
            y_smooth = medfilt1(y, SmoothWindow);
        else
            y_smooth = smoothdata(y, 'movmean', SmoothWindow);
        end
        Results.Cross{st}.L_smooth = y_smooth;
    end
end

%% ===================== 7. 绘图部分 =====================
figure('Name', 'Phase Noise Analysis', 'Color', 'w', 'Position', [100, 100, 800, 600]);
hold on; grid on; box on;

% 定义线型和颜色
colors = lines(NumStages);

% 绘制自谱
for st = 1:NumStages
    if isfield(Results.Auto{st}, 'L_smooth')
        plot(Results.Auto{st}.f, Results.Auto{st}.L_smooth, ...
            'Color', colors(st,:), ...
            'LineWidth', 1.5, ...
            'DisplayName', Results.Auto{st}.Label);
    end
end

% 绘制互谱
for st = 1:NumStages
    if isfield(Results.Cross{st}, 'L_smooth')
        plot(Results.Cross{st}.f, Results.Cross{st}.L_smooth, ...
            'Color', colors(st,:), ...
            'LineStyle', '--', ...
            'LineWidth', 1.5, ...
            'DisplayName', Results.Cross{st}.Label);
    end
end

% 图形美化
set(gca, 'XScale', 'log', 'YScale', 'linear');
xlabel('Frequency (Hz)', 'FontSize', 12);
ylabel('Phase Noise L(f) (dBc/Hz)', 'FontSize', 12);
title('Phase Noise Spectrum', 'FontSize', 14);
lgd = legend('show', 'Location', 'best');

% --- 坐标轴范围调整 ---
ylim_auto = ylim;
ylim([-180, ylim_auto(2) * 1.1]);

% --- 强制设置字体 ---
set(findall(gcf, '-property', 'FontName'), 'FontName', 'Times New Roman', 'FontSize', 12);
try
    set(lgd, 'FontName', 'Times New Roman', 'Interpreter', 'none');
catch
    set(findall(gcf, 'Type', 'legend'), 'FontName', 'Times New Roman');
end
drawnow;

%% ===================== 8. 保存结果 =====================
save('pn_avg_results_from_phase_files.mat', 'Results', 'Spectra');
fprintf('\n🎉 所有计算完成，平滑结果已保存并绘图。\n');


%% ===================== 9. 子函数：读取相位并计算自谱 =====================
function [f_plot, L_plot, info] = read_phase_psd(fname, Fs, nfft, maxAvg, low_cut_idx, dtrend_mode)
    % 1. 读取相位数据 (直接读取 double)
    fid = fopen(fname, 'rb');
    if fid < 0, error('无法打开文件: %s', fname); end
    phi_raw = fread(fid, 'double');
    fclose(fid);

    % 2. 预处理参数
    win = hann(nfft, 'periodic');
    noverlap = floor(nfft/2);
    step = nfft - noverlap;

    % 限制最大处理长度 (为了模拟平均次数)
    maxLen = maxAvg * step + noverlap;
    if length(phi_raw) > maxLen
        phi_raw = phi_raw(1:maxLen);
    end

    % 3. 去趋势
    if dtrend_mode == 0
        opt = 'linear';
    else
        opt = 'constant';
    end
    phi_detrended = detrend(phi_raw, opt);

    % 4. 计算功率谱密度 (PSD)
    [Pphi, f] = pwelch(phi_detrended, win, noverlap, nfft, Fs, 'onesided');

    % 5. 转换为相位噪声 L(f)
    L = 10 * log10(Pphi / 2);

    % 6. 频率筛选
    if low_cut_idx >= numel(f), low_cut_idx = 2; end
    mask = (f > f(low_cut_idx)) & (f < Fs*0.45);

    f_plot = f(mask);
    L_plot = L(mask);

    % 7. 统计信息
    info.actual_avg = floor((length(phi_detrended) - noverlap) / step);
end

%% ===================== 10. 子函数：读取相位并计算互谱 =====================
function [f_plot, L_plot, info] = read_phase_cpsd(fileListA, fileListB, Fs, nfft, low_cut_idx, dtrend_mode)
    % 读取 A 通道
    fidA = fopen(fileListA{1}, 'rb');
    phiA = fread(fidA, 'double');
    fclose(fidA);

    % 读取 B 通道
    fidB = fopen(fileListB{1}, 'rb');
    phiB = fread(fidB, 'double');
    fclose(fidB);

    % 取较短长度
    len = min(length(phiA), length(phiB));
    phiA = phiA(1:len);
    phiB = phiB(1:len);

    % 去趋势
    if dtrend_mode == 0
        opt = 'linear';
    else
        opt = 'constant';
    end
    phiA = detrend(phiA, opt);
    phiB = detrend(phiB, opt);

    % 计算互功率谱密度 (CPSD)
    win = hann(nfft, 'periodic');
    noverlap = floor(nfft/2);
    [Pxy, f] = cpsd(phiA, phiB, win, noverlap, nfft, Fs, 'onesided');

    % 转换为互谱相位噪声
    L = 10 * log10(abs(Pxy) / 2);

    % 频率筛选
    if low_cut_idx >= numel(f), low_cut_idx = 2; end
    mask = (f > f(low_cut_idx)) & (f < Fs*0.45);

    f_plot = f(mask);
    L_plot = L(mask);

    info.actual_avg = 1;
end